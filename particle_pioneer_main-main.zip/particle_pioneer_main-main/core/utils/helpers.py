from web3 import Web3


def generate_evm_account():
    connection = Web3()

    account = connection.eth.account.create()
    address = account.address

    return address
