from asyncio import sleep
from loguru import logger


RETRY_COUNT = 3


def retry(func):
    async def wrapper(*args, **kwargs):
        retries = 0
        while retries <= RETRY_COUNT:
            try:
                result = await func(*args, **kwargs)
                return result
            except Exception as e:
                logger.error(f"RETRY function | Some error | {e}")
                await sleep(10, 20)
                retries += 1
            
                if retries == RETRY_COUNT:
                    raise e
    return wrapper
