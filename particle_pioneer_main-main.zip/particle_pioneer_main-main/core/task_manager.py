import random
import uuid
import asyncio
import pandas
import traceback

from datetime import datetime, timezone
from web3 import Account as ethAccount
from tqdm import tqdm

from core.data_loader import DataLoader
from core.particle import ParticleNetwork
from core.utils import FileManager
from loguru import logger

from core.database.database import MainDB
from core.database.models import Accounts

from data.config import MAIN_NETWORK, TIMEOUT_PROXY, DEPOSIT_USDG, MAKE_TRANSACTIONS, GET_ALL_BALANCES, EXPORT_DATA, EXPORT_SEPARATOR, ENABLE_CROSSCHAIN_TX, ENABLE_PURCHASE_NFT, ENABLE_RETWEET, STOP_ANY_ERROR
from data.service import NETWORK_BYKEY


class TaskManager:
    def __init__(self, filter_: list | None) -> None:
        self.lock = asyncio.Lock()
        self.__db = MainDB()
        self.__dl = DataLoader(lock=self.lock)
        self.__network = NETWORK_BYKEY[MAIN_NETWORK]
        self._apply_filter(filter_)
            
    def _apply_filter(self, filter_: list | None) -> None:
        if filter_:
            self.__dl.accounts = self.__db.get_accounts_filtered(
                checkin=('Check-in failed' in filter_),
                todaytx=('No 100 transactions' in filter_)
            )

    async def launch(self, thread: int, storage: str) -> None:
        while True:
            try:
                if storage == 'Launch DataBase':
                    account = await self.__dl.get_account()
                    if account == 'noaccount':return account

                    logger.info(f'Поток {thread} | Начал работу - <i>PrivateKey: <u><g>{account.private_key[:5]}***{account.private_key[61:]}</g></u></i>')
                    self.__db.update_account(account.id, {'check_in': False})

                    particle = ParticleNetwork(thread, account, self.__network)
                    login_data = await particle.login()
                
                    points_stats = await particle.check_earned_points()

                    if not any(item.get('points', None) == 3 for item in points_stats):
                        balance_main = await particle.get_balance(self.__network.chain_id, account.address)
                        deposit_amount = round(random.uniform(DEPOSIT_USDG[0], DEPOSIT_USDG[1]), 6)
                        if balance_main > deposit_amount:
                            await particle.deposit_usdg(deposit_amount)
                            logger.success(f'Поток {thread} | Задание <c>DEPOSIT UNIVERSAL GAS</c> выполнено! | <i>Points: <g>+200</g> <m>$PARTI</m></i>')
                        else:
                            logger.critical(f'Поток {thread} | <r>Баланс на основном EVM кошельке закончился, транзакции будут пропущены!</r> | <r>Баланс: {balance_main} ${self.__network.token}</r>')
                            
                    if ENABLE_RETWEET:
                        if not any(item['type'] == 5 for item in points_stats):
                            result = await particle.claim_retweet()
                            if result:
                                logger.success(f'Поток {thread} | Задание <c>RETWEET PARTICLE NETWORKS TWEET</c> выполнено! | <i>Points: <g>+1000</g> <m>$PARTI</m></i>')
                            else:
                                logger.error(f'Поток {thread} | Ошибка при выполнении задания <r>RETWEET PARTICLE NETWORKS TWEET</r>')

                    checkin = await particle.auto_checkin()

                    if ENABLE_PURCHASE_NFT:
                        history_nft = await particle.get_purchase_nft_history()
                        purchase_count_today = 0

                        timestamp = ParticleNetwork.get_unix_timestamp()

                        for trade in history_nft:
                            created_at = trade.get('createdAt', None)
                            trade_parsed_time = datetime.strptime(created_at, "%Y-%m-%dT%H:%M:%S.%fZ")
                            trade_time_utc = trade_parsed_time.replace(tzinfo=timezone.utc).timestamp()

                            if timestamp - trade_time_utc <= 86400:
                                purchase_count_today += 1
                        
                        purchase_count_make = 10 - purchase_count_today
                        if purchase_count_make > 0:
                            await particle.auto_purchase_nft(purchase_count_make)
                    
                    if ENABLE_CROSSCHAIN_TX:
                        transactions = await particle.get_lpcross_transactions()
                        transaction_count_today = 0

                        timestamp = ParticleNetwork.get_unix_timestamp()

                        for trade in transactions:
                            created_at = trade.get('createdAt', None)
                            trade_parsed_time = datetime.strptime(created_at, "%Y-%m-%dT%H:%M:%S.%fZ")
                            trade_time_utc = trade_parsed_time.replace(tzinfo=timezone.utc).timestamp()

                            if timestamp - trade_time_utc <= 86400:
                                transaction_count_today += 1
                        
                        transaction_count_make = 50 - transaction_count_today
                        if transaction_count_make > 0:
                            await particle.auto_crosschain(transaction_count_make)
                    
                    logger.info(f'Поток {thread} | Собираю информацию/статистику аккаунта...')
                    
                    points_stats = await particle.check_earned_points(logl=True)
                    user_info = await particle.get_user_info()

                    referral_points, checkin_points, deposit_points, transactions_points, retweet_points, crosschain_points, nft_points = 0, 0, 0, 0, 0, 0, 0

                    for item in points_stats:
                        if item['type'] == 1:
                            referral_points = int(item['point'])
                        elif item['type'] == 2:
                            checkin_points = int(item['point'])
                        elif item['type'] == 3:
                            deposit_points = int(item['point'])
                        elif item['type'] == 4:
                            transactions_points = int(item['point'])
                        elif item['type'] == 5:
                            retweet_points = int(item['point'])
                        elif item['type'] == 6:
                            crosschain_points = int(item['point'])
                        elif item['type'] == 7:
                            nft_points = int(item['point'])

                    all_transactions = []
                    transaction_count_today = 0

                    page = 1
                    while True:
                        transactions = await particle.get_transactions(page)
                        page += 1
                        if transactions:
                            all_transactions.extend(transactions)
                        else:
                            break

                    timestamp = ParticleNetwork.get_unix_timestamp()

                    for trade in all_transactions:
                        created_at = trade.get('createdAt', None)
                        trade_parsed_time = datetime.strptime(created_at, "%Y-%m-%dT%H:%M:%S.%fZ")
                        trade_time_utc = trade_parsed_time.replace(tzinfo=timezone.utc).timestamp()

                        if timestamp - trade_time_utc <= 86400:
                            transaction_count_today += 1

                    all_transactions_cross = []
                    transaction_count_today_cross = 0

                    page = 1
                    while True:
                        transactions_cross = await particle.get_lpcross_transactions(page=page)
                        page += 1
                        if transactions_cross:
                            all_transactions_cross.extend(transactions)
                        else:
                            break

                    timestamp = ParticleNetwork.get_unix_timestamp()

                    for trade in all_transactions_cross:
                        created_at = trade.get('createdAt', None)
                        trade_parsed_time = datetime.strptime(created_at, "%Y-%m-%dT%H:%M:%S.%fZ")
                        trade_time_utc = trade_parsed_time.replace(tzinfo=timezone.utc).timestamp()

                        if timestamp - trade_time_utc <= 86400:
                            transaction_count_today_cross += 1

                    balances = await particle.get_all_balances() if GET_ALL_BALANCES else {}

                    data_update = {
                        'invite_code': user_info['invitationCode'],
                        'referrer_address': user_info['referrerAddress'],
                        
                        'check_in': checkin,
                        'today_tx_crosschain': transaction_count_today_cross,
                        'total_tx_crosschain': len(all_transactions_cross),
                        'today_tx_ord': transaction_count_today,
                        'total_tx_ord': len(all_transactions),
                        
                        'referral_points': referral_points,
                        'checkin_points': checkin_points,
                        'deposit_points': deposit_points,
                        'transactions_points': transactions_points,
                        'retweet_points': retweet_points,
                        'crosschain_points': crosschain_points,
                        'nft_points': nft_points,
                        'total_points': user_info['totalPoint'],
                        **balances
                    }
                    self.__db.update_account(account.id, data_update)
                    logger.success(f'Поток {thread} | Информация и статистика аккаунта в базе данных обновлена!')
                    logger.success(f'Поток {thread} | Завершил работу - <u><i>PrivateKey: <g>{account.private_key[:5]}***{account.private_key[61:]}</g></i></u>')
                else:
                    wallet = await self.__dl.get_wallet(thread)
                    if wallet == 'nowallet':return wallet

                    logger.info(f'Поток {thread} | Начал работу - <u><i>PrivateKey: <g>{wallet[:5]}***{wallet[61:]}</g></i></u>')

                    proxy = await self.__dl.get_proxy(thread, TIMEOUT_PROXY)
                    if proxy == 'noproxy':return proxy
                    
                    account = Accounts(
                        address=ethAccount.from_key(wallet).address,
                        private_key=wallet,
                        twitter_token='This account has already been registered',
                        proxy=proxy,
                        device_id=str(uuid.uuid4()),
                        refcode='This account has already been registered'
                    )

                    particle = ParticleNetwork(thread, account, self.__network)
                    login_data = await particle.login()

                    account.address_particle = login_data['aaAddress']

                    if login_data['referrerAddress'] is None:
                        account.refcode = await self.__dl.get_refcode()
                        await particle.enter_refcode()
                    else:
                        logger.info(f'Поток {thread} | К аккаунту уже привязан <c>RefCode</c>!')
                    
                    if login_data['twitterId'] is None:
                        twitter = await self.__dl.get_twitter(thread, proxy)
                        if twitter == 'notwitter':return twitter
                        account.twitter_token = twitter
                        await particle.bind_twitter(twitter)
                    else:
                        logger.info(f'Поток {thread} | К аккаунту уже привязан <c>Twitter</c>!')

                    self.__db.add_account(account)
                    logger.info(f'Поток {thread} | Добавил аккаунт в БД - <u><i>PrivateKey: <g>{wallet[:5]}***{wallet[61:]}</g></i></u>')

            except Exception as error:
                logger.critical(f"Непредвиденная ошибка: <r>{type(error).__name__}</r> - <r>{str(error)}</r>")
                logger.critical(f"Полный traceback ошибки:\n<r>{traceback.format_exc()}</r>")

                if STOP_ANY_ERROR:
                    raise
    
    async def generate_wallets(self, thread: int, number: int) -> None:
        all_wallets = ''
        with tqdm(
            total=number,
            colour='green',
            unit=' wallets',
        ) as pbar:
            for _ in range(number):
                acct = ethAccount.create()
                all_wallets += acct.key.hex() +'\n'
                pbar.update(1)
                
        FileManager.save_data('data/generate/wallets.txt', all_wallets)
        print("")
        logger.success(f"Успешно сгенерировано <g>{number}</g> кошельков, сохранил по пути -> <c>data/generate/wallets.txt</c>")
        return ''
    
    async def export_info(self, thread: int, keys: list, format_: str):
        accounts = self.__dl.accounts
        export_list = EXPORT_DATA.replace(" ","").split(",") if keys[0] == 'From config.py' else keys

        if format_ == 'TXT':
            data = ''
            for account in accounts:
                for export in export_list:
                    if export == 'check_in':
                        data += ('✅' if getattr(account, export) else '❌') + EXPORT_SEPARATOR
                    else:
                        data += str(getattr(account, export)) + EXPORT_SEPARATOR
                data = data[:-len(EXPORT_SEPARATOR)] + '\n'
                logger.info(f"Аккаунт <g>{account.private_key}</g> экспортирован!")
            FileManager.save_data('data/export/wallets.txt', data)
            logger.success(f"Успешно экспортировано <g>{len(accounts)}</g> кошельков, сохранил по пути -> <c>data/export/wallets.txt</c>")
        else:
            df = pandas.DataFrame(columns=[export.capitalize() for export in export_list])
            for account in accounts:
                row_data = []
                for export in export_list:
                    if export == 'check_in':
                        row_data.append('✅' if getattr(account, export) else '❌')
                    else:
                        row_data.append(str(getattr(account, export)))
                df.loc[len(df)] = row_data
                logger.info(f"Аккаунт <g>{account.private_key}</g> экспортирован!")
            excel_file_path = 'data/export/wallets.xlsx'
            df.to_excel(excel_file_path, index=False) 
            logger.success(f"Успешно экспортировано <g>{len(accounts)}</g> кошельков, сохранил по пути -> <c>data/export/wallets.xlsx</c>")
        return ''

