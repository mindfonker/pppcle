class RequestsAttempts(Exception):
    pass

